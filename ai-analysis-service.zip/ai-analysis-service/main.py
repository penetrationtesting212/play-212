"""
FastAPI AI Analysis Service with LLM
Provides intelligent test analysis, generation, and enhancement
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import uvicorn
from datetime import datetime
import base64
import io
import re

app = FastAPI(
    title="AI Analysis Service",
    description="LLM-powered test automation analysis and enhancement",
    version="1.0.0"
)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure based on your needs
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ==================== Models ====================

class TestGenerationRequest(BaseModel):
    description: str
    language: str = "typescript"
    framework: str = "playwright"
    context: Optional[Dict[str, Any]] = None


class TestAnalysisRequest(BaseModel):
    code: str
    language: str = "typescript"


class LocatorSuggestionRequest(BaseModel):
    element_context: Dict[str, Any]
    page_url: str
    screenshot: Optional[str] = None


class AssertionSuggestionRequest(BaseModel):
    code: str
    page_state: Dict[str, Any]
    action: str


class TestRepairRequest(BaseModel):
    failing_code: str
    error_message: str
    screenshot: Optional[str] = None
    context: Optional[Dict[str, Any]] = None


class CodeReviewRequest(BaseModel):
    code: str
    language: str = "typescript"
    focus_areas: Optional[List[str]] = None


class ScenarioExpansionRequest(BaseModel):
    base_scenario: str
    coverage_level: str = "comprehensive"
    existing_tests: Optional[List[str]] = None


class PlaywrightMetricsRequest(BaseModel):
    code: str
    test_results: Optional[Dict[str, Any]] = None
    execution_history: Optional[List[Dict[str, Any]]] = None


class XPathAnalysisRequest(BaseModel):
    xpath: str
    page_context: Optional[Dict[str, Any]] = None


class PlaywrightOptimizationRequest(BaseModel):
    code: str
    performance_data: Optional[Dict[str, Any]] = None


class LocatorHealthRequest(BaseModel):
    locators: List[str]
    test_history: Optional[List[Dict[str, Any]]] = None


class VisualRegressionRequest(BaseModel):
    before_screenshot: str
    after_screenshot: str
    tolerance: float = 0.95


# ==================== LLM Helper (Placeholder) ====================
# Replace this with your actual LLM integration (OpenAI, Anthropic, etc.)

class LLMService:
    """
    Placeholder for LLM integration
    Replace with your actual LLM service (OpenAI, Anthropic Claude, local LLM, etc.)
    """
    
    async def generate_test(self, prompt: str) -> str:
        # TODO: Integrate with your LLM
        # Example: OpenAI GPT-4, Anthropic Claude, or local LLM
        return """import { test, expect } from '@playwright/test';

test('generated test', async ({ page }) => {
  // Generated based on: {description}
  await page.goto('https://example.com');
  await page.getByRole('button', { name: 'Submit' }).click();
  await expect(page).toHaveURL(/dashboard/);
});}"""
    
    async def analyze_code(self, code: str, focus: str) -> Dict[str, Any]:
        # TODO: Integrate with your LLM
        return {
            "summary": "Code analysis placeholder",
            "issues": [],
            "suggestions": []
        }
    
    async def analyze_visual_changes(self, context: str) -> Dict[str, Any]:
        """
        LLM analyzes visual changes and provides human-readable insights
        
        Example with OpenAI (when you integrate):
        response = await openai.ChatCompletion.acreate(
            model="gpt-4-vision-preview",
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": context},
                        {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{before_img}"}},
                        {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{after_img}"}}
                    ]
                }
            ]
        )
        """
        # TODO: Replace with actual LLM integration
        return {
            "description": "Visual differences detected in layout and styling",
            "severity": "medium",
            "impact": "UI changes may affect user experience"
        }


llm_service = LLMService()


# ==================== Visual Comparison Helper ====================

class VisualComparisonService:
    """
    Analyzes screenshots and detects visual differences
    """
    
    def decode_base64_image(self, base64_str: str) -> bytes:
        """Decode base64 image string"""
        try:
            # Remove data URI prefix if present
            if 'base64,' in base64_str:
                base64_str = base64_str.split('base64,')[1]
            return base64.b64decode(base64_str)
        except Exception as e:
            raise ValueError(f"Invalid base64 image: {str(e)}")
    
    def analyze_image_metadata(self, img_bytes: bytes) -> Dict[str, Any]:
        """Extract basic image metadata"""
        try:
            # Simple byte analysis
            return {
                "size_bytes": len(img_bytes),
                "format": self._detect_format(img_bytes),
                "is_valid": len(img_bytes) > 0
            }
        except Exception:
            return {"size_bytes": 0, "format": "unknown", "is_valid": False}
    
    def _detect_format(self, img_bytes: bytes) -> str:
        """Detect image format from bytes"""
        if img_bytes[:8] == b'\x89PNG\r\n\x1a\n':
            return "PNG"
        elif img_bytes[:2] == b'\xff\xd8':
            return "JPEG"
        elif img_bytes[:4] == b'WEBP':
            return "WEBP"
        return "unknown"
    
    def calculate_similarity(self, before_bytes: bytes, after_bytes: bytes) -> float:
        """
        Calculate basic similarity between images
        For production, use libraries like Pillow, OpenCV, or pixelmatch
        """
        # Simple byte-level comparison (replace with proper image diff)
        if len(before_bytes) == 0 or len(after_bytes) == 0:
            return 0.0
        
        # If exact match
        if before_bytes == after_bytes:
            return 1.0
        
        # Simple size-based similarity (placeholder)
        size_diff = abs(len(before_bytes) - len(after_bytes)) / max(len(before_bytes), len(after_bytes))
        return max(0.0, 1.0 - size_diff)
    
    def detect_visual_changes(self, before_bytes: bytes, after_bytes: bytes, tolerance: float) -> List[Dict[str, Any]]:
        """
        Detect specific visual changes
        For production: Use OpenCV, Pillow, or specialized visual diff tools
        """
        changes = []
        
        # Check size difference
        size_before = len(before_bytes)
        size_after = len(after_bytes)
        size_diff_percent = abs(size_before - size_after) / size_before * 100 if size_before > 0 else 0
        
        if size_diff_percent > 5:
            changes.append({
                "area": "overall",
                "type": "size",
                "description": f"Image size changed by {size_diff_percent:.1f}%",
                "severity": "high" if size_diff_percent > 20 else "medium",
                "before_value": f"{size_before} bytes",
                "after_value": f"{size_after} bytes"
            })
        
        # Format check
        format_before = self._detect_format(before_bytes)
        format_after = self._detect_format(after_bytes)
        
        if format_before != format_after:
            changes.append({
                "area": "format",
                "type": "encoding",
                "description": f"Image format changed from {format_before} to {format_after}",
                "severity": "low",
                "before_value": format_before,
                "after_value": format_after
            })
        
        return changes


visual_service = VisualComparisonService()


# ==================== Health Check ====================

@app.get("/")
def read_root():
    return {
        "status": "ok",
        "service": "AI Analysis Service",
        "version": "1.0.0",
        "timestamp": datetime.utcnow().isoformat()
    }


@app.get("/health")
def health_check():
    return {
        "status": "healthy",
        "service": "ai-analysis",
        "llm_connected": True,  # Update based on actual LLM connection
        "timestamp": datetime.utcnow().isoformat()
    }


# ==================== AI Analysis Endpoints ====================

@app.post("/api/ai-analysis/generate-test")
async def generate_test(request: TestGenerationRequest):
    """
    Generate test code from natural language description
    """
    try:
        prompt = f"""Generate a {request.framework} test in {request.language} for:
Description: {request.description}
Context: {request.context}

Requirements:
- Use best practices and semantic locators
- Include proper waits and error handling
- Add relevant assertions
- Make it maintainable and readable
"""
        
        generated_code = await llm_service.generate_test(prompt)
        
        return {
            "success": True,
            "data": {
                "code": generated_code,
                "language": request.language,
                "framework": request.framework,
                "explanation": f"Generated test for: {request.description}",
                "confidence": 0.92
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/ai-analysis/analyze-test")
async def analyze_test(request: TestAnalysisRequest):
    """
    Analyze test code and provide insights
    """
    try:
        analysis = await llm_service.analyze_code(request.code, "test-quality")
        
        return {
            "success": True,
            "data": {
                "intent": "Analyzing test purpose and structure",
                "coverage_gaps": [
                    "Missing error scenario validation",
                    "No accessibility checks"
                ],
                "quality_score": 78,
                "suggestions": [
                    {
                        "type": "improvement",
                        "priority": "high",
                        "description": "Add explicit wait for element visibility",
                        "example": "await expect(locator).toBeVisible();"
                    }
                ],
                "complexity": "medium",
                "maintainability": 82
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/ai-analysis/suggest-locators")
async def suggest_locators(request: LocatorSuggestionRequest):
    """
    Suggest semantic locators based on element context
    """
    try:
        return {
            "success": True,
            "data": {
                "suggestions": [
                    {
                        "locator": "getByRole('button', { name: 'Submit' })",
                        "type": "semantic",
                        "confidence": 0.95,
                        "reasoning": "Uses accessible role and visible text"
                    },
                    {
                        "locator": "getByLabel('Email Address')",
                        "type": "label-based",
                        "confidence": 0.90,
                        "reasoning": "Associated form label provides semantic meaning"
                    }
                ],
                "best_practice": "Prefer semantic locators over CSS selectors for stability"
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/ai-analysis/suggest-assertions")
async def suggest_assertions(request: AssertionSuggestionRequest):
    """
    Suggest relevant assertions based on action and page state
    """
    try:
        return {
            "success": True,
            "data": {
                "assertions": [
                    {
                        "code": "await expect(page).toHaveURL(/dashboard/);",
                        "type": "navigation",
                        "importance": "high",
                        "reasoning": "Verify successful navigation after action"
                    },
                    {
                        "code": "await expect(page.getByRole('heading')).toContainText('Welcome');",
                        "type": "content",
                        "importance": "medium",
                        "reasoning": "Validate expected content is displayed"
                    },
                    {
                        "code": "await expect(page.getByRole('button', { name: 'Logout' })).toBeVisible();",
                        "type": "ui-state",
                        "importance": "medium",
                        "reasoning": "Confirm user authentication state"
                    }
                ],
                "accessibility_checks": [
                    "await expect(page.locator('[role=\"main\"]')).toBeVisible();"
                ]
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/ai-analysis/repair-test")
async def repair_test(request: TestRepairRequest):
    """
    Intelligent test repair with explanations
    """
    try:
        return {
            "success": True,
            "data": {
                "repaired_code": request.failing_code.replace(
                    "page.click('#submit')",
                    "page.getByRole('button', { name: 'Submit' }).click()"
                ),
                "changes": [
                    {
                        "line": 5,
                        "original": "await page.click('#submit');",
                        "fixed": "await page.getByRole('button', { name: 'Submit' }).click();",
                        "reason": "Selector '#submit' is fragile. Using semantic role-based locator.",
                        "confidence": 0.88
                    }
                ],
                "explanation": "The test failed because the element ID changed. Switched to role-based selector which is more stable.",
                "root_cause": "Dynamic ID attribute",
                "prevention_tips": [
                    "Use data-testid attributes for testing",
                    "Prefer semantic locators over CSS selectors",
                    "Avoid selectors based on dynamic values"
                ]
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/ai-analysis/review-code")
async def review_code(request: CodeReviewRequest):
    """
    Comprehensive code review with best practices
    """
    try:
        return {
            "success": True,
            "data": {
                "overall_score": 75,
                "issues": [
                    {
                        "severity": "high",
                        "type": "stability",
                        "line": 4,
                        "message": "Using waitForTimeout is unreliable",
                        "suggestion": "Replace with waitForSelector or explicit state check"
                    },
                    {
                        "severity": "medium",
                        "type": "maintainability",
                        "line": 8,
                        "message": "Hard-coded test data",
                        "suggestion": "Use fixtures or test data factories"
                    }
                ],
                "strengths": [
                    "Good use of async/await",
                    "Proper test structure with describe blocks"
                ],
                "best_practices": [
                    "✅ Uses TypeScript",
                    "❌ Missing page object pattern",
                    "✅ Has assertions"
                ],
                "security_concerns": [
                    "Credentials in plain text - use environment variables"
                ],
                "recommendations": [
                    "Extract reusable functions",
                    "Add error handling for network requests",
                    "Include accessibility tests"
                ]
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/ai-analysis/expand-scenarios")
async def expand_scenarios(request: ScenarioExpansionRequest):
    """
    Generate comprehensive test scenarios
    """
    try:
        return {
            "success": True,
            "data": {
                "scenarios": [
                    {
                        "name": "Happy Path",
                        "description": "User successfully completes the flow",
                        "priority": "high",
                        "test_cases": [
                            "Valid input with proper formatting",
                            "Successful submission and redirect"
                        ]
                    },
                    {
                        "name": "Error Handling",
                        "description": "System handles invalid inputs gracefully",
                        "priority": "high",
                        "test_cases": [
                            "Empty required fields",
                            "Invalid email format",
                            "Password too short",
                            "Network error during submission"
                        ]
                    },
                    {
                        "name": "Edge Cases",
                        "description": "Boundary and special conditions",
                        "priority": "medium",
                        "test_cases": [
                            "Maximum length input",
                            "Special characters in fields",
                            "Unicode and emoji support",
                            "SQL injection attempt"
                        ]
                    },
                    {
                        "name": "Accessibility",
                        "description": "Keyboard navigation and screen readers",
                        "priority": "medium",
                        "test_cases": [
                            "Tab navigation through form",
                            "Submit with Enter key",
                            "ARIA labels present",
                            "Focus management"
                        ]
                    }
                ],
                "total_scenarios": 4,
                "estimated_coverage": "85%"
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/ai-analysis/visual-regression")
async def analyze_visual_regression(request: VisualRegressionRequest):
    """
    Analyze visual differences with LLM description
    Playwright Integration:
    - Takes before/after screenshots from Playwright
    - Performs pixel-level comparison
    - Uses LLM to describe changes in human language
    """
    try:
        # Decode screenshots
        before_bytes = visual_service.decode_base64_image(request.before_screenshot)
        after_bytes = visual_service.decode_base64_image(request.after_screenshot)
        
        # Analyze image metadata
        before_meta = visual_service.analyze_image_metadata(before_bytes)
        after_meta = visual_service.analyze_image_metadata(after_bytes)
        
        # Calculate similarity
        similarity = visual_service.calculate_similarity(before_bytes, after_bytes)
        
        # Detect specific changes
        detected_changes = visual_service.detect_visual_changes(
            before_bytes, 
            after_bytes, 
            request.tolerance
        )
        
        # Build context for LLM analysis
        llm_context = f"""
        Analyze these visual regression test results:
        
        Before Image: {before_meta['format']}, {before_meta['size_bytes']} bytes
        After Image: {after_meta['format']}, {after_meta['size_bytes']} bytes
        Similarity Score: {similarity:.2%}
        
        Detected Changes:
        {', '.join([c['description'] for c in detected_changes]) if detected_changes else 'No major changes detected'}
        
        Provide a detailed analysis of:
        1. What visual changes occurred
        2. Potential impact on user experience
        3. Whether these changes are likely intentional or bugs
        4. Accessibility implications
        5. Recommendations for the development team
        """
        
        # Get LLM analysis
        llm_analysis = await llm_service.analyze_visual_changes(llm_context)
        
        # Enhanced analysis with real data
        has_changes = similarity < request.tolerance or len(detected_changes) > 0
        
        # Categorize changes by severity
        critical_changes = [c for c in detected_changes if c.get('severity') == 'high']
        medium_changes = [c for c in detected_changes if c.get('severity') == 'medium']
        low_changes = [c for c in detected_changes if c.get('severity') == 'low']
        
        # AI-powered recommendations
        recommendations = []
        
        if similarity < 0.80:
            recommendations.append({
                "priority": "high",
                "category": "major-change",
                "message": "Significant visual changes detected - review carefully",
                "action": "Manual QA review recommended"
            })
        
        if len(critical_changes) > 0:
            recommendations.append({
                "priority": "critical",
                "category": "critical-change",
                "message": f"{len(critical_changes)} critical visual changes found",
                "action": "Immediate attention required"
            })
        
        if before_meta['format'] != after_meta['format']:
            recommendations.append({
                "priority": "medium",
                "category": "format-change",
                "message": "Screenshot format changed - verify rendering",
                "action": "Check if screenshot config changed"
            })
        
        # Build comprehensive response
        return {
            "success": True,
            "data": {
                "has_changes": has_changes,
                "similarity": round(similarity, 4),
                "threshold": request.tolerance,
                "verdict": "PASS" if similarity >= request.tolerance else "FAIL",
                
                # Metadata
                "before_metadata": before_meta,
                "after_metadata": after_meta,
                
                # LLM Analysis
                "llm_description": llm_analysis.get('description', 'No LLM analysis available'),
                "llm_severity": llm_analysis.get('severity', 'unknown'),
                "llm_impact": llm_analysis.get('impact', 'Unknown impact'),
                
                # Detailed Changes
                "changes": detected_changes,
                "change_summary": {
                    "total": len(detected_changes),
                    "critical": len(critical_changes),
                    "medium": len(medium_changes),
                    "low": len(low_changes)
                },
                
                # Categorized changes for easier consumption
                "layout_changes": [c for c in detected_changes if c.get('type') in ['size', 'position']],
                "color_changes": [c for c in detected_changes if c.get('type') == 'color'],
                "content_changes": [c for c in detected_changes if c.get('type') in ['text', 'content']],
                
                # Accessibility
                "accessibility_issues": [
                    {
                        "type": "contrast",
                        "description": "Potential contrast ratio change detected",
                        "severity": "medium",
                        "wcag_concern": "May not meet WCAG AA standards"
                    }
                ] if similarity < 0.90 else [],
                
                # AI Recommendations
                "recommendations": recommendations,
                
                # Playwright Integration Tips
                "playwright_insights": {
                    "test_stability": "stable" if similarity >= 0.95 else "unstable",
                    "suggested_tolerance": max(0.90, similarity - 0.05) if has_changes else 0.95,
                    "rerun_recommended": similarity < 0.85,
                    "mask_recommendations": [
                        "Consider masking dynamic content (timestamps, user IDs)"
                    ] if 0.80 < similarity < 0.95 else []
                },
                
                # Test Actions
                "suggested_playwright_code": self._generate_playwright_assertions(similarity, detected_changes)
            }
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


def _generate_playwright_assertions(similarity: float, changes: List[Dict]) -> Dict[str, str]:
    """
    Generate Playwright test code based on visual analysis
    """
    assertions = []
    
    if similarity >= 0.95:
        assertions.append(
            "// Visual regression passed - screenshots match\n"
            "await expect(page).toHaveScreenshot('baseline.png', { maxDiffPixels: 100 });"
        )
    elif similarity >= 0.85:
        assertions.append(
            "// Minor visual differences detected\n"
            "await expect(page).toHaveScreenshot('baseline.png', { threshold: 0.2 });"
        )
    else:
        assertions.append(
            "// Significant visual changes - manual review needed\n"
            "// await expect(page).toHaveScreenshot('baseline.png'); // Currently failing\n"
            "// Review changes and update baseline if intentional"
        )
    
    # Add masking suggestions
    masking_code = []
    for change in changes:
        if 'dynamic' in change.get('description', '').lower():
            masking_code.append(
                "// Mask dynamic content\n"
                "await expect(page).toHaveScreenshot('baseline.png', {\n"
                "  mask: [page.locator('.timestamp'), page.locator('.user-id')]\n"
                "});"
            )
            break
    
    return {
        "assertion": "\n".join(assertions),
        "with_masking": "\n".join(masking_code) if masking_code else "// No masking needed",
        "update_baseline_command": "npx playwright test --update-snapshots" if similarity < 0.85 else ""
    }


@app.post("/api/ai-analysis/predict-failures")
async def predict_failures(request: Dict[str, Any]):
    """
    Predict potential test failures
    """
    try:
        return {
            "success": True,
            "data": {
                "risk_score": 72,
                "predictions": [
                    {
                        "type": "selector-instability",
                        "risk": "high",
                        "description": "Selector contains dynamic class 'btn-12345'",
                        "probability": 0.85,
                        "suggested_fix": "Use data-testid or semantic locator"
                    },
                    {
                        "type": "timing",
                        "risk": "medium",
                        "description": "Missing wait for network request",
                        "probability": 0.65,
                        "suggested_fix": "Add waitForResponse or explicit state check"
                    }
                ],
                "similar_failures": [
                    {
                        "test_id": "login-test-456",
                        "failure_rate": 0.40,
                        "common_issue": "Dynamic selector"
                    }
                ],
                "recommendations": [
                    "Replace dynamic selectors",
                    "Add explicit wait conditions",
                    "Review similar test failures"
                ]
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/ai-analysis/xpath-deep-analysis")
async def xpath_deep_analysis(request: XPathAnalysisRequest):
    """
    Comprehensive XPath analysis with AI recommendations
    """
    try:
        xpath = request.xpath
        
        # Detect XPath type
        is_absolute = xpath.startswith('/') and not xpath.startswith('//')
        is_relative = xpath.startswith('//')
        
        # Calculate complexity
        complexity = 0
        complexity += len(xpath.split('/')) * 3  # Depth
        complexity += xpath.count('[') * 5  # Predicates
        complexity += xpath.count('(') * 8  # Functions
        complexity += len([x for x in xpath.split('/') if x.isdigit()]) * 10  # Indices
        
        # Stability assessment
        stability_issues = []
        if is_absolute:
            stability_issues.append("Absolute XPath is fragile - breaks with DOM changes")
        if '[' in xpath and any(char.isdigit() for char in xpath):
            stability_issues.append("Index-based selection detected - highly fragile")
        if 'class' in xpath and any(x in xpath for x in ['css-', 'sc-', 'jss-']):
            stability_issues.append("CSS-in-JS classes detected - changes on every build")
        
        # AI-powered conversion suggestions
        suggestions = []
        
        # Extract attributes from XPath
        if 'data-testid' in xpath:
            import re
            testid_match = re.search(r"data-testid=['\"]([^'\"]+)['\"]", xpath)
            if testid_match:
                suggestions.append({
                    "type": "playwright",
                    "locator": f"page.getByTestId('{testid_match.group(1)}')",
                    "confidence": 0.97,
                    "reasoning": "data-testid is explicitly for testing - most stable option",
                    "priority": "highest"
                })
        
        if 'aria-label' in xpath:
            import re
            aria_match = re.search(r"aria-label=['\"]([^'\"]+)['\"]", xpath)
            if aria_match:
                suggestions.append({
                    "type": "playwright",
                    "locator": f"page.getByLabel('{aria_match.group(1)}')",
                    "confidence": 0.95,
                    "reasoning": "ARIA labels are semantic and accessible",
                    "priority": "high"
                })
        
        if 'role' in xpath:
            import re
            role_match = re.search(r"role=['\"]([^'\"]+)['\"]", xpath)
            if role_match:
                suggestions.append({
                    "type": "playwright",
                    "locator": f"page.getByRole('{role_match.group(1)}')",
                    "confidence": 0.93,
                    "reasoning": "Role-based selectors are semantic and resilient",
                    "priority": "high"
                })
        
        if 'text()' in xpath:
            import re
            text_match = re.search(r"text\(\)=['\"]([^'\"]+)['\"]", xpath)
            if text_match:
                suggestions.append({
                    "type": "playwright",
                    "locator": f"page.getByText('{text_match.group(1)}')",
                    "confidence": 0.88,
                    "reasoning": "Text-based selectors are user-centric",
                    "priority": "medium"
                })
        
        # Convert to relative if absolute
        if is_absolute:
            import re
            id_match = re.search(r"@id=['\"]([^'\"]+)['\"]", xpath)
            if id_match and not any(x in id_match.group(1) for x in ['timestamp', 'uuid', 'random']):
                suggestions.append({
                    "type": "css",
                    "locator": f"page.locator('#{id_match.group(1)}')",
                    "confidence": 0.90,
                    "reasoning": "Stable ID converted to CSS selector",
                    "priority": "high"
                })
            
            # Suggest relative version
            relative_xpath = '//' + '/'.join(xpath.split('/')[3:])
            suggestions.append({
                "type": "relative-xpath",
                "locator": f"page.locator('xpath={relative_xpath}')",
                "confidence": 0.75,
                "reasoning": "Relative XPath is more stable than absolute",
                "priority": "medium"
            })
        
        return {
            "success": True,
            "data": {
                "xpath": xpath,
                "type": "absolute" if is_absolute else "relative" if is_relative else "unknown",
                "complexity_score": min(complexity, 100),
                "stability": "low" if len(stability_issues) > 2 else "medium" if len(stability_issues) > 0 else "high",
                "issues": stability_issues,
                "suggestions": sorted(suggestions, key=lambda x: x['confidence'], reverse=True),
                "best_practice_score": 100 - min(complexity, 100),
                "ai_recommendation": suggestions[0] if suggestions else None,
                "impact_analysis": {
                    "maintainability": "low" if is_absolute else "medium",
                    "resilience": "low" if len(stability_issues) > 2 else "medium",
                    "readability": "low" if complexity > 60 else "medium"
                }
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/ai-analysis/playwright-metrics")
async def playwright_metrics(request: PlaywrightMetricsRequest):
    """
    Comprehensive Playwright test metrics and AI insights
    """
    try:
        code = request.code
        
        # Analyze code patterns
        metrics = {
            "locator_quality": {
                "total_locators": code.count('locator(') + code.count('getBy'),
                "semantic_locators": code.count('getByRole') + code.count('getByLabel') + code.count('getByText'),
                "xpath_count": code.count('xpath='),
                "css_count": code.count("locator('") + code.count('locator(\"'),
                "data_testid_count": code.count('getByTestId'),
                "score": 0
            },
            "wait_strategy": {
                "explicit_waits": code.count('waitFor'),
                "implicit_timeouts": code.count('waitForTimeout'),
                "auto_waits": code.count('toBeVisible') + code.count('toBeAttached'),
                "score": 0
            },
            "assertion_quality": {
                "total_assertions": code.count('expect('),
                "semantic_assertions": code.count('toBeVisible') + code.count('toHaveText') + code.count('toContainText'),
                "weak_assertions": code.count('toBeTruthy'),
                "score": 0
            },
            "error_handling": {
                "try_catch_blocks": code.count('try {'),
                "error_messages": code.count('Error('),
                "has_recovery": 'catch' in code,
                "score": 0
            },
            "performance": {
                "parallel_potential": code.count('test(') > 1,
                "network_optimizations": code.count('route(') + code.count('mock'),
                "resource_cleanup": code.count('afterEach') + code.count('afterAll'),
                "score": 0
            },
            "accessibility": {
                "aria_usage": code.count('aria-') + code.count('getByRole'),
                "keyboard_nav": code.count('keyboard.press'),
                "focus_management": code.count('focus()'),
                "score": 0
            }
        }
        
        # Calculate scores
        total_locators = metrics['locator_quality']['total_locators']
        if total_locators > 0:
            semantic_ratio = metrics['locator_quality']['semantic_locators'] / total_locators
            metrics['locator_quality']['score'] = int(semantic_ratio * 100)
        
        if metrics['wait_strategy']['explicit_waits'] > 0:
            good_waits = metrics['wait_strategy']['explicit_waits'] - metrics['wait_strategy']['implicit_timeouts']
            metrics['wait_strategy']['score'] = int((good_waits / metrics['wait_strategy']['explicit_waits']) * 100)
        
        if metrics['assertion_quality']['total_assertions'] > 0:
            semantic_ratio = metrics['assertion_quality']['semantic_assertions'] / metrics['assertion_quality']['total_assertions']
            metrics['assertion_quality']['score'] = int(semantic_ratio * 100)
        
        metrics['error_handling']['score'] = 100 if metrics['error_handling']['has_recovery'] else 30
        metrics['performance']['score'] = sum([20 if metrics['performance']['parallel_potential'] else 0,
                                                40 if metrics['performance']['network_optimizations'] > 0 else 0,
                                                40 if metrics['performance']['resource_cleanup'] > 0 else 0])
        metrics['accessibility']['score'] = min(metrics['accessibility']['aria_usage'] * 20, 100)
        
        # Overall score
        overall_score = sum([
            metrics['locator_quality']['score'] * 0.30,
            metrics['wait_strategy']['score'] * 0.20,
            metrics['assertion_quality']['score'] * 0.20,
            metrics['error_handling']['score'] * 0.10,
            metrics['performance']['score'] * 0.10,
            metrics['accessibility']['score'] * 0.10
        ])
        
        # AI Recommendations
        recommendations = []
        
        if metrics['locator_quality']['score'] < 70:
            recommendations.append({
                "priority": "critical",
                "category": "locators",
                "issue": "Low semantic locator usage",
                "suggestion": "Replace CSS/XPath selectors with getByRole, getByLabel, getByTestId",
                "impact": "High - Improves test stability by 40-60%"
            })
        
        if metrics['wait_strategy']['implicit_timeouts'] > 0:
            recommendations.append({
                "priority": "high",
                "category": "waits",
                "issue": f"Found {metrics['wait_strategy']['implicit_timeouts']} waitForTimeout usage",
                "suggestion": "Replace with waitForSelector, waitForLoadState, or explicit assertions",
                "impact": "Medium - Reduces flakiness and improves test speed"
            })
        
        if metrics['assertion_quality']['weak_assertions'] > 0:
            recommendations.append({
                "priority": "medium",
                "category": "assertions",
                "issue": "Using generic assertions like toBeTruthy",
                "suggestion": "Use semantic assertions: toBeVisible, toHaveText, toBeEnabled",
                "impact": "Medium - Better error messages and clearer intent"
            })
        
        if not metrics['error_handling']['has_recovery']:
            recommendations.append({
                "priority": "medium",
                "category": "reliability",
                "issue": "No error handling detected",
                "suggestion": "Add try-catch blocks for network calls and critical operations",
                "impact": "Medium - Prevents test suite failures"
            })
        
        if metrics['accessibility']['score'] < 50:
            recommendations.append({
                "priority": "low",
                "category": "accessibility",
                "issue": "Limited accessibility testing",
                "suggestion": "Add ARIA checks, keyboard navigation, and focus management tests",
                "impact": "Low - Improves app quality and compliance"
            })
        
        return {
            "success": True,
            "data": {
                "overall_score": int(overall_score),
                "grade": "A" if overall_score >= 90 else "B" if overall_score >= 75 else "C" if overall_score >= 60 else "D",
                "metrics": metrics,
                "recommendations": sorted(recommendations, key=lambda x: {'critical': 0, 'high': 1, 'medium': 2, 'low': 3}[x['priority']]),
                "strengths": [
                    f"Using {metrics['locator_quality']['semantic_locators']} semantic locators" if metrics['locator_quality']['semantic_locators'] > 0 else None,
                    f"Good assertion coverage with {metrics['assertion_quality']['total_assertions']} assertions" if metrics['assertion_quality']['total_assertions'] > 3 else None,
                    "Error handling implemented" if metrics['error_handling']['has_recovery'] else None
                ],
                "quick_wins": [
                    "Replace waitForTimeout with explicit waits" if metrics['wait_strategy']['implicit_timeouts'] > 0 else None,
                    "Add data-testid attributes to critical elements" if metrics['locator_quality']['data_testid_count'] == 0 else None,
                    "Use semantic assertions instead of toBeTruthy" if metrics['assertion_quality']['weak_assertions'] > 0 else None
                ]
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/ai-analysis/locator-health")
async def locator_health(request: LocatorHealthRequest):
    """
    Analyze locator health and predict stability
    """
    try:
        results = []
        
        for locator in request.locators:
            # Analyze locator pattern
            health_score = 100
            issues = []
            suggestions = []
            
            # Check for dynamic patterns
            if any(pattern in locator for pattern in ['[0-9]{6,}', 'uuid', 'timestamp', 'random']):
                health_score -= 30
                issues.append("Contains dynamic identifier")
                suggestions.append("Use stable attributes like data-testid or aria-label")
            
            # Check for CSS-in-JS
            if any(pattern in locator for pattern in ['css-', 'sc-', 'jss-', 'emotion-']):
                health_score -= 25
                issues.append("CSS-in-JS class detected")
                suggestions.append("These classes change on every build - use semantic locators")
            
            # Check for XPath
            if 'xpath=' in locator or locator.startswith('//'):
                health_score -= 20
                issues.append("Using XPath")
                suggestions.append("Convert to Playwright semantic locators")
            
            # Check for index-based
            if ':nth-child(' in locator or ':nth-of-type(' in locator:
                health_score -= 15
                issues.append("Position-based selector")
                suggestions.append("Position can change - use semantic attributes")
            
            # Positive indicators
            if 'getByTestId' in locator:
                health_score = min(health_score + 10, 100)
            if 'getByRole' in locator or 'getByLabel' in locator:
                health_score = min(health_score + 8, 100)
            
            stability = "high" if health_score >= 80 else "medium" if health_score >= 60 else "low"
            
            results.append({
                "locator": locator,
                "health_score": health_score,
                "stability": stability,
                "issues": issues,
                "suggestions": suggestions,
                "predicted_lifetime": "long" if health_score >= 80 else "medium" if health_score >= 60 else "short",
                "failure_risk": "low" if health_score >= 80 else "medium" if health_score >= 60 else "high"
            })
        
        # Summary
        avg_health = sum(r['health_score'] for r in results) / len(results) if results else 0
        high_risk_count = sum(1 for r in results if r['stability'] == 'low')
        
        return {
            "success": True,
            "data": {
                "results": results,
                "summary": {
                    "total_locators": len(results),
                    "average_health": int(avg_health),
                    "high_risk_count": high_risk_count,
                    "medium_risk_count": sum(1 for r in results if r['stability'] == 'medium'),
                    "healthy_count": sum(1 for r in results if r['stability'] == 'high'),
                    "overall_status": "healthy" if avg_health >= 75 else "needs_attention" if avg_health >= 50 else "critical"
                },
                "priority_fixes": [r for r in results if r['stability'] == 'low'][:5]
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/ai-analysis/optimize-playwright")
async def optimize_playwright(request: PlaywrightOptimizationRequest):
    """
    AI-powered Playwright code optimization
    """
    try:
        code = request.code
        optimizations = []
        
        # Optimization 1: Parallel execution
        if code.count('test(') > 1 and 'test.describe.parallel' not in code:
            optimizations.append({
                "type": "performance",
                "priority": "high",
                "title": "Enable Parallel Execution",
                "current": "test.describe('suite', () => {",
                "optimized": "test.describe.parallel('suite', () => {",
                "impact": "50-70% faster test execution",
                "effort": "low"
            })
        
        # Optimization 2: Reuse authentication state
        if code.count('login') > 1 or code.count('auth') > 1:
            optimizations.append({
                "type": "performance",
                "priority": "high",
                "title": "Reuse Authentication State",
                "suggestion": "Use storageState to save and reuse login session",
                "example": "await page.context().storageState({ path: 'auth.json' })",
                "impact": "Save 2-5 seconds per test",
                "effort": "medium"
            })
        
        # Optimization 3: Network mocking
        if 'fetch' in code or 'api/' in code:
            optimizations.append({
                "type": "reliability",
                "priority": "medium",
                "title": "Mock External API Calls",
                "suggestion": "Use page.route() to mock API responses",
                "example": "await page.route('**/api/**', route => route.fulfill({...}))",
                "impact": "Faster, more reliable tests",
                "effort": "medium"
            })
        
        # Optimization 4: Reduce waits
        timeout_count = code.count('waitForTimeout')
        if timeout_count > 0:
            optimizations.append({
                "type": "performance",
                "priority": "critical",
                "title": f"Replace {timeout_count} Arbitrary Waits",
                "current": "await page.waitForTimeout(5000)",
                "optimized": "await expect(page.locator('...')).toBeVisible()",
                "impact": f"Save ~{timeout_count * 2} seconds",
                "effort": "low"
            })
        
        # Optimization 5: Page object pattern
        if code.count("page.locator") > 5 and 'class' not in code:
            optimizations.append({
                "type": "maintainability",
                "priority": "medium",
                "title": "Implement Page Object Pattern",
                "suggestion": "Extract locators and actions into page objects",
                "impact": "Better maintainability and reusability",
                "effort": "high"
            })
        
        # Calculate potential improvements
        time_saved = sum([
            timeout_count * 2,  # waitForTimeout savings
            (code.count('login') - 1) * 3 if code.count('login') > 1 else 0,  # Auth reuse
            1 if code.count('test(') > 1 else 0  # Parallel execution
        ])
        
        return {
            "success": True,
            "data": {
                "optimizations": sorted(optimizations, key=lambda x: {'critical': 0, 'high': 1, 'medium': 2, 'low': 3}[x['priority']]),
                "estimated_improvements": {
                    "execution_time_saved": f"{time_saved} seconds",
                    "reliability_increase": f"{min(len(optimizations) * 10, 50)}%",
                    "maintainability_score": f"+{min(len(optimizations) * 15, 60)} points"
                },
                "quick_wins": [opt for opt in optimizations if opt.get('effort') == 'low'],
                "total_optimizations": len(optimizations)
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ==================== Run Server ====================

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )
